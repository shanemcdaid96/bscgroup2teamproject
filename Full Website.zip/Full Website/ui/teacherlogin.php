 <?php  
 $connect = mysqli_connect("92.222.96.254","oliver","Opert213","email");  
 session_start();  
 // if(isset($_SESSION["username"]))  
 // {  
 //      header("location:entry.php");  
 // }  
 if(isset($_POST["register"]))  
 {  
      if(empty($_POST["username"]) || empty($_POST["password"]))  
      {  
           echo '<script>alert("Both Fields are required")</script>';  
      }  
      else  
      { 
        $p_username = $_POST['username'] . "@bsafe-email.com";
        $sql="SELECT * FROM teacher WHERE username ='".$p_username."'";
        $result=mysqli_query($connect,$sql);
        if(mysqli_num_rows($result)>=1){
          echo"name already taken";
        }
        else{
           $username = mysqli_real_escape_string($connect, $_POST["username"]);  
           $password = mysqli_real_escape_string($connect, $_POST["password"]);  
           $hashpassword = password_hash($password, PASSWORD_DEFAULT);  
           $param_username = $username . "@bsafe-email.com";
           $query = "INSERT INTO teacher(username, password,name) VALUES('$param_username', '$hashpassword','$username')";  
           if(mysqli_query($connect, $query))  
           {  
                echo '<script>alert("Registration Done")</script>';  
            } 
           } 
      }  
 }  
 if(isset($_POST["login"]))  
 {  
      if(empty($_POST["username"]) || empty($_POST["password"]))  
      {  
           echo '<script>alert("Both Fields are required")</script>';  
      }  
      else  
      {  
           $username = mysqli_real_escape_string($connect, $_POST["username"]);  
           $password = mysqli_real_escape_string($connect, $_POST["password"]);  
           $hashpassword = password_hash($password, PASSWORD_DEFAULT); 
           $param_username = $username . "@bsafe-email.com";
           $query = "SELECT * FROM teacher WHERE username = '$param_username'";  
           $result = mysqli_query($connect, $query);  
           if(mysqli_num_rows($result) > 0)  
           {  
                while($row = mysqli_fetch_array($result))  
                {  
                     if(password_verify($password, $hashpassword))  
                     {  
                          //return true;  
                          $_SESSION["username"] = $param_username;  
                          header("location:entry.php");  
                     }  
                     else  
                     {  
                          //return false;  
                          echo '<script>alert("Wrong User Details")</script>';  
                     }  
                }  
           }  
           else  
           {  
                echo '<script>alert("Wrong User Details")</script>';  
           }  
      }  
 }  
 ?>  

<!DOCTYPE html>
<!--  This site was created in Webflow. http://www.webflow.com  -->
<!--  Last Published: Wed Feb 14 2018 12:58:24 GMT+0000 (UTC)  -->
<html data-wf-page="5a84198463b7e50001e365e7" data-wf-site="5a84198463b7e50001e365e6">
<head>
  <meta charset="utf-8">
  <title>Bsafe - Teacher Login</title>
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <meta content="Webflow" name="generator">
  <link href="css/normalize.css" rel="stylesheet" type="text/css">
  <link href="css/custom.css" rel="stylesheet" type="text/css">
  <link href="css/webflow.css" rel="stylesheet" type="text/css">
  <link href="css/loop-d2a242-f9fcb5a64213c8fd3510148bf02.webflow.css" rel="stylesheet" type="text/css">
  <!-- [if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js" type="text/javascript"></script><![endif] -->
  <script type="text/javascript">!function(o,c){var n=c.documentElement,t=" w-mod-";n.className+=t+"js",("ontouchstart"in o||o.DocumentTouch&&c instanceof DocumentTouch)&&(n.className+=t+"touch")}(window,document);</script>
  <link href="https://daks2k3a4ib2z.cloudfront.net/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
  <link href="https://daks2k3a4ib2z.cloudfront.net/img/webclip.png" rel="apple-touch-icon">
</head>
<body class="body">
  <div class="row w-row">
    <div class="w-col w-col-3 w-col-medium-3"></div>
    <div class="column w-col w-col-6 w-col-medium-6">
      <div class="div-block">
        <div class="w-form">
          <center><h3>Teacher Login</h3></center>
          <form id="email-form" name="email-form" data-name="Email Form" class="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

            <input type="text" class="w-input-email" maxlength="256" name="username"  placeholder="Username" id="email" required="" value="<?php echo $username; ?>">
            <input class="w-input-email"  placeholder="@bsafe-email.com" readonly>

            <input type="password" class="w-input" maxlength="256" name="password" data-name="password" placeholder="Password" id="password" required="">

            <input type="submit" value="Login" data-wait="Please wait..." class="submit-button w-button">

            <p style="text-align:center">Dont have an account?<a style="text-align:center" href="teacherReg.php">Register</a></p>
            <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>"></div>

            
            <br>



            </form>
          
          
        </div>
      </div>
    </div>
    <div class="w-col w-col-3 w-col-medium-3"></div>
  </div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js" type="text/javascript"></script>
  <script src="js/webflow.js" type="text/javascript"></script>
  <script src="js/custom.js" type="text/javascript"></script>
  <!-- [if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif] -->
</body>
</html>