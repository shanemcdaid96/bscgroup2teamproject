<?php


//Connecting to sql db.
session_start();
$connect = mysqli_connect("92.222.96.254","oliver","Opert213","email");

$username= $_SESSION['username'] ;

$resultID = mysqli_query($connect,"SELECT id FROM teacher WHERE username Like '".$username."'"); 
$jfeta = mysqli_fetch_assoc($resultID);
$id = $jfeta['id'];
$_SESSION['id'] = $id;

if (mysqli_num_rows($resultID) == 0)
  {
//echo "<script> alert('No ID');
//</script>";
//echo $id;

}
else{
	echo "<script> alert('ID Avaiable');</script>";

}

//Sending form data to sql db.
$Title=$_POST['title']; 
$Message=$_POST['message'];

$date=date('y-m-d');


$sql="INSERT INTO updates (Title, UpdateMessage,Date,Teacher)
        VALUES ('$Title','$Message','$date','$id')";

          $result = mysqli_query($connect,$sql);
if($result){
    echo "Successful";
    header('Location:sentUpdates.php');

}
else {
    echo "ERROR";
      //	echo "<script> alert('$username');</script>";
}


?>